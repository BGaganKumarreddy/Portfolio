const express = require('express');
const router = express.Router();
const nodemailer = require('nodemailer');

router.post('/', async (req, res) => {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
        return res.status(400).json({ error: 'Please fill in all fields' });
    }

    // If no email credentials are provided, log the message (Dev mode)
    if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
        console.log('--- EMAIL SIMULATION ---');
        console.log(`From: ${name} <${email}>`);
        console.log(`Message: ${message}`);
        console.log('------------------------');
        return res.status(200).json({ message: 'Message sent successfully (Simulation)' });
    }

    try {
        const transporter = nodemailer.createTransport({
            service: 'gmail', // Can be changed to other providers
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS,
            },
        });

        const mailOptions = {
            from: process.env.EMAIL_USER, // Sender address matches the authenticated user
            to: process.env.EMAIL_USER, // Send to yourself
            replyTo: email, // Allow replying to the user
            subject: `Portfolio Contact: ${name}`,
            text: `Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`,
        };

        await transporter.sendMail(mailOptions);
        res.status(200).json({ message: 'Message sent successfully' });
    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).json({ error: 'Failed to send message' });
    }
});

module.exports = router;
