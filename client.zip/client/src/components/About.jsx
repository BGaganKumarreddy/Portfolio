import React from 'react';
import { motion } from 'framer-motion';
import { Code, Database, Layout, Smartphone } from 'lucide-react';

const About = () => {
    const skills = [
        "JavaScript (ES6+)", "React", "Node.js", "TypeScript",
        "Tailwind CSS", "MongoDB", "PostgreSQL", "Next.js",
        "Docker", "AWS", "Git", "Figma"
    ];

    const services = [
        {
            icon: <Layout className="w-8 h-8 text-indigo-400" />,
            title: "Frontend Development",
            desc: "Building responsive, pixel-perfect user interfaces with modern frameworks."
        },
        {
            icon: <Database className="w-8 h-8 text-cyan-400" />,
            title: "Backend Development",
            desc: "Architecting robust APIs and server-side logic for scalable applications."
        },
        {
            icon: <Smartphone className="w-8 h-8 text-purple-400" />,
            title: "Mobile First",
            desc: "Ensuring optimal performance and experience across all device sizes."
        }
    ];

    return (
        <section id="about" className="py-24 bg-slate-950 relative">
            <div className="max-w-7xl mx-auto px-6">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                    className="mb-16"
                >
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">About <span className="text-gradient">Me</span></h2>
                    <div className="w-20 h-1.5 bg-indigo-600 rounded-full"></div>
                </motion.div>

                <div className="grid md:grid-cols-2 gap-16 items-start">
                    {/* Text Content */}
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                    >
                        <p className="text-slate-300 text-lg leading-relaxed mb-6">
                            I am a passionate software engineer with a strong foundation in both frontend and backend technologies.
                            My journey started with simple static pages and evolved into complex, data-driven web applications.
                        </p>
                        <p className="text-slate-300 text-lg leading-relaxed mb-8">
                            I believe in clean code, user-centric design, and continuous learning.
                            When I'm not coding, you can find me exploring new tech trends, contributing to open source, or gaming.
                        </p>

                        <h3 className="text-xl font-semibold mb-4 text-white">Tech Stack</h3>
                        <div className="flex flex-wrap gap-3">
                            {skills.map((skill, index) => (
                                <span
                                    key={index}
                                    className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 text-sm hover:border-indigo-500 hover:text-indigo-400 transition-colors cursor-default"
                                >
                                    {skill}
                                </span>
                            ))}
                        </div>
                    </motion.div>

                    {/* Service Cards */}
                    <div className="grid gap-6">
                        {services.map((service, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, x: 20 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: 0.3 + (index * 0.1) }}
                                className="p-6 rounded-2xl glass hover:bg-slate-900/80 transition-colors"
                            >
                                <div className="flex items-start gap-4">
                                    <div className="p-3 bg-slate-800/50 rounded-xl">
                                        {service.icon}
                                    </div>
                                    <div>
                                        <h4 className="text-lg font-semibold text-white mb-2">{service.title}</h4>
                                        <p className="text-slate-400 text-sm">{service.desc}</p>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default About;
