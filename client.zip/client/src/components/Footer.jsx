import React from 'react';

const Footer = () => {
    return (
        <footer className="py-8 bg-slate-950 border-t border-slate-900 text-center">
            <div className="max-w-7xl mx-auto px-6">
                <p className="text-slate-500 text-sm">
                    © {new Date().getFullYear()} Gagan Portfolio. All rights reserved.
                </p>
                <div className="flex justify-center gap-6 mt-4">
                    <a href="#" className="text-slate-500 hover:text-white transition-colors text-sm">Github</a>
                    <a href="#" className="text-slate-500 hover:text-white transition-colors text-sm">LinkedIn</a>
                    <a href="#" className="text-slate-500 hover:text-white transition-colors text-sm">Twitter</a>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
