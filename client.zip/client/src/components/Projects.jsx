import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';

const Projects = () => {
    const projects = [
        {
            title: "E-Commerce Dashboard",
            desc: "A comprehensive dashboard for managing products, orders, and analytics. Features real-time data visualization.",
            tags: ["React", "Tailwind", "Chart.js", "Node.js"],
            github: "#",
            demo: "#",
            // Using a gradient placeholder instead of image for now
            color: "from-blue-600 to-indigo-600"
        },
        {
            title: "Task Management App",
            desc: "Collaborative task manager with drag-and-drop kanban board and team features.",
            tags: ["Next.js", "TypeScript", "Prisma", "PostgreSQL"],
            github: "#",
            demo: "#",
            color: "from-emerald-600 to-teal-600"
        },
        {
            title: "AI Content Generator",
            desc: "SaaS application that uses OpenAI API to generate marketing copy and blog posts.",
            tags: ["React", "OpenAI API", "Stripe", "Firebase"],
            github: "#",
            demo: "#",
            color: "from-purple-600 to-pink-600"
        }
    ];

    return (
        <section id="projects" className="py-24 bg-slate-900 relative border-y border-slate-800/50">
            <div className="max-w-7xl mx-auto px-6">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                    className="mb-16"
                >
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured <span className="text-gradient">Projects</span></h2>
                    <div className="w-20 h-1.5 bg-indigo-600 rounded-full mb-6"></div>
                    <p className="text-slate-400 max-w-2xl">
                        Here are some of the projects I've worked on. Each one presented unique challenges
                        and learning opportunities.
                    </p>
                </motion.div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {projects.map((project, index) => (
                        <motion.div
                            key={index}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            className="group rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden hover:border-indigo-500/50 transition-all duration-300 hover:shadow-2xl hover:shadow-indigo-500/10"
                        >
                            {/* Image Placeholder */}
                            <div className={`h-48 bg-gradient-to-br ${project.color} relative overflow-hidden`}>
                                <div className="absolute inset-0 bg-slate-950/20 group-hover:bg-transparent transition-colors duration-300" />
                            </div>

                            <div className="p-6">
                                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">
                                    {project.title}
                                </h3>
                                <p className="text-slate-400 text-sm mb-6 line-clamp-3">
                                    {project.desc}
                                </p>

                                <div className="flex flex-wrap gap-2 mb-6">
                                    {project.tags.map((tag, i) => (
                                        <span key={i} className="text-xs px-2 py-1 rounded bg-slate-900 text-slate-300 border border-slate-800">
                                            {tag}
                                        </span>
                                    ))}
                                </div>

                                <div className="flex items-center gap-4">
                                    <a href={project.github} className="flex items-center gap-2 text-sm font-medium text-slate-300 hover:text-white transition-colors">
                                        <Github size={18} /> Code
                                    </a>
                                    <a href={project.demo} className="flex items-center gap-2 text-sm font-medium text-indigo-400 hover:text-indigo-300 transition-colors">
                                        <ExternalLink size={18} /> Live Demo
                                    </a>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Projects;
