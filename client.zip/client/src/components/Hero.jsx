import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Download } from 'lucide-react';
import profileImg from '../assets/Profile.png';
import resume from '../assets/gagan cv.pdf';

const Hero = () => {
    return (
        <section id="home" className="min-h-screen flex items-center justify-center pt-20 relative overflow-hidden">
            {/* Background blobs */}
            <div className="absolute top-20 left-10 w-72 h-72 bg-indigo-600/20 rounded-full blur-[100px]" />
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-cyan-600/10 rounded-full blur-[100px]" />

            <div className="max-w-7xl mx-auto px-6 relative z-10 w-full grid md:grid-cols-2 gap-12 items-center">
                {/* Text Content */}
                <div className="text-center md:text-left order-2 md:order-1">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                    >
                        <span className="inline-block py-1 px-3 rounded-full bg-slate-800/50 border border-slate-700 text-sm text-indigo-400 mb-6">
                            Available for hire
                        </span>
                    </motion.div>

                    <motion.h1
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.1 }}
                        className="text-5xl md:text-7xl font-bold tracking-tight mb-6"
                    >
                        Building <span className="text-gradient">Digital Experiences</span>
                        <br /> That Matter.
                    </motion.h1>

                    <motion.p
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                        className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto md:mx-0 mb-10"
                    >
                        I'm a Full Stack Engineer specializing in building exceptional digital products.
                        Currently focused on building accessible, human-centered products.
                    </motion.p>

                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5, delay: 0.3 }}
                        className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start"
                    >
                        <a
                            href="#projects"
                            className="group px-8 py-3 rounded-full bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
                        >
                            View Projects
                            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                        </a>
                        <a
                            href={resume}
                            download="Gagan_Reddy_Resume.pdf"
                            className="px-8 py-3 rounded-full bg-slate-800 text-slate-200 font-medium hover:bg-slate-700 transition-all flex items-center justify-center gap-2"
                        >
                            Download CV
                            <Download size={18} />
                        </a>
                    </motion.div>
                </div>

                {/* Image Content */}
                <motion.div
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className="order-1 md:order-2 flex justify-center relative"
                >
                    <div className="relative w-64 h-64 md:w-80 md:h-80 lg:w-96 lg:h-96">
                        <div className="absolute inset-0 bg-gradient-to-tr from-indigo-600 to-cyan-600 rounded-full blur-[20px] opacity-50 animate-pulse"></div>
                        <div className="absolute inset-4 bg-slate-950 rounded-full z-10"></div>
                        <div className="absolute inset-4 overflow-hidden rounded-full z-20 border-4 border-slate-800/50 flex items-center justify-center bg-slate-900">
                            {/* 
                  PLACEHOLDER: Replace the src below with your local image.
                  Example: src="/my-profile-pic.jpg" if in public folder,
                  or import it at the top if in assets.
                */}
                            <img
                                src={profileImg}
                                alt="Profile"
                                className="w-full h-full object-cover object-top"
                                onError={(e) => {
                                    e.target.style.display = 'none'; // Hide if image load fails
                                    e.target.nextSibling.style.display = 'block'; // Show fallback text
                                }}
                            />
                            <div className="hidden text-slate-500 text-sm text-center px-4">
                                Add your photo here: <br /> src/assets/profile.jpg
                            </div>
                        </div>
                    </div>
                </motion.div>
            </div>
        </section>
    );
};

export default Hero;
