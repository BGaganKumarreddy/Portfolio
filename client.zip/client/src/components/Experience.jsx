import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, GraduationCap, Calendar } from 'lucide-react';

const Experience = () => {
    const experiences = [
        {
            type: 'work',
            role: 'Senior Frontend Engineer',
            company: 'Tech Solutions Inc.',
            period: '2023 - Present',
            desc: 'Leading a team of 5 developers building a SaaS platform. Improved performance by 40%.'
        },
        {
            type: 'work',
            role: 'Full Stack Developer',
            company: 'Digital Agency',
            period: '2021 - 2023',
            desc: 'Developed multiple client projects using MERN stack. Mentored junior developers.'
        },
        {
            type: 'education',
            role: 'B.Tech in Computer Science',
            company: 'University of Technology',
            period: '2017 - 2021',
            desc: 'Graduated with Distinction. Specialized in Artificial Intelligence.'
        }
    ];

    return (
        <section id="experience" className="py-24 bg-slate-950 relative">
            <div className="max-w-4xl mx-auto px-6">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5 }}
                    className="mb-16 text-center"
                >
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">Experience & <span className="text-gradient">Education</span></h2>
                    <div className="w-20 h-1.5 bg-indigo-600 rounded-full mx-auto"></div>
                </motion.div>

                <div className="relative">
                    {/* Vertical Line */}
                    <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-slate-800 transform md:-translate-x-1/2 ml-4 md:ml-0"></div>

                    <div className="space-y-12">
                        {experiences.map((item, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.5, delay: index * 0.1 }}
                                className={`relative flex flex-col md:flex-row gap-8 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''
                                    }`}
                            >
                                {/* Dot */}
                                <div className="absolute left-0 md:left-1/2 top-0 w-8 h-8 rounded-full bg-slate-900 border-2 border-indigo-500 z-10 transform -translate-x-1/2 md:-translate-x-1/2 ml-4 md:ml-0 flex items-center justify-center">
                                    <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                                </div>

                                {/* Content */}
                                <div className="ml-12 md:ml-0 md:w-1/2 px-4">
                                    <div className={`p-6 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-indigo-500/30 transition-colors ${index % 2 === 0 ? 'md:text-left' : 'md:text-right'
                                        }`}>
                                        <div className={`flex items-center gap-2 mb-2 ${index % 2 === 0 ? 'md:justify-start' : 'md:justify-end'
                                            }`}>
                                            {item.type === 'work' ? (
                                                <Briefcase className="w-4 h-4 text-indigo-400" />
                                            ) : (
                                                <GraduationCap className="w-4 h-4 text-emerald-400" />
                                            )}
                                            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                                                {item.type}
                                            </span>
                                        </div>

                                        <h3 className="text-xl font-bold text-white mb-1">{item.role}</h3>
                                        <h4 className="text-lg text-indigo-400 mb-4">{item.company}</h4>

                                        <div className={`flex items-center gap-2 text-sm text-slate-500 mb-4 ${index % 2 === 0 ? 'md:justify-start' : 'md:justify-end'
                                            }`}>
                                            <Calendar className="w-4 h-4" />
                                            {item.period}
                                        </div>

                                        <p className="text-slate-400 text-sm leading-relaxed">
                                            {item.desc}
                                        </p>
                                    </div>
                                </div>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Experience;
